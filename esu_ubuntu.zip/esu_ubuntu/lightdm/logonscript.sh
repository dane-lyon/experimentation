if mount | grep -q "/tmp/netlogon" ; then umount /tmp/netlogon ;fi
